let myApp = angular.module("myApp",["ngRoute"]);
myApp.config(function($routeProvider){
    $routeProvider.when(
        "/list",{
templateUrl:"views/list.html",
controller: listController
        }
    ).when(
        "/add-bv",{
        templateUrl:"views/add.html",
        controller: addController
    }).when("/detail/:id",{
        templateUrl:"views/detail.html",
        controller: detailController
    }).when("/update/:id",
        {
            templateUrl:"views/update.html",
            controller: updateController
        }
    )
    .otherwise({
        redirectTo:"/list"
    })
})