window.listController = function($scope, $http){
    $scope.listTitle="List bai viet";
    const api = "http://localhost:3000/baiviet";
    function getAll(){
        $http.get(api).then(function(response){
            if(response.status ==200){
                $scope.listbv = response.data;
            }else{
                alert("api false");
            }
        });
    }
    getAll();
    $scope.deletebv = function(id){
        let confirm = window.confirm("Ban co muon xoa khong?");
        if(confirm){
            $http.delete(`${api}/${id}`                
            ).then(function(response){
                if(response.status ==200){
alert("da xoa thanh cong");
getAll();
                }
            });
        }
    }
}