window.addController = function($scope, $http, $location){
    $scope.addTitle = "ADD"
    const api ="http://localhost:3000/baiviet";
    $scope.add = function(){
        let newbv ={
            tieu_de : $scope.input.tieu_de,
            noi_dung : $scope.input.noi_dung,
            tac_gia: $scope.input.tac_gia,
            the_loai: $scope.select.the_loai,
            ngay_dang: $scope.input.ngay_dang,
        };
        $http.post(
            api,newbv
        ).then(function(response){
            if(response.status ==201){
                alert("Success");
                $location.path("/list");
            }
        });
    }
}