window.updateController = function($scope, $http, $location, $routeParams){
    $scope.uploadTitle="UPDATE";
    let id = $routeParams.id;
    const api ="http://localhost:3000/baiviet";
    $http.get(api + '/' +id).then(function(response){
        if(response.status ==200){
            $scope.input={
                id: response.data.id,
                tieu_de: response.data.tieu_de,
                noi_dung: response.data.noi_dung,
                tac_gia: response.data.tac_gia,
                ngay_dang: new Date(response.data.ngay_dang),
            };
            $scope.select={
                the_loai: response.data.the_loai,
            }
        }
    });
    $scope.update = function(){
    let newbv ={
        tieu_de: $scope.input.tieu_de,
        noi_dung: $scope.input.noi_dung,
        tac_gia: $scope.input.tac_gia,
        the_loai: $scope.input.the_loai,
        ngay_dang: $scope.input.ngay_dang,
    }
    $http.put(
        api +'/'+id, newbv
    ).then(function(response){
        if(response.status ==200){
            alert("Update thanh cong");
            $location.path("/list");
        }
    });
}
}