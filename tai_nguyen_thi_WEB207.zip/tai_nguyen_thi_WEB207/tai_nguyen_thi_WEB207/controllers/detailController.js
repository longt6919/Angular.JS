window.detailController = function($scope, $http, $routeParams){
    $scope.detailTitle ="Detail";
    let id = $routeParams.id;
    const api ="http://localhost:3000/baiviet";
    $http.get(api +"/" +id)
        .then(function(response){
            if(response.status ==200){
                $scope.input ={
                    id:response.data.id,
                    tieu_de: response.data.tieu_de,
                    noi_dung: response.data.noi_dung,
                    tac_gia: response.data.tac_gia,
                    ngay_dang: new Date(response.data.ngay_dang),
                };
                $scope.select ={
                    the_loai: response.data.the_loai,
                }
            }
        });
    
}